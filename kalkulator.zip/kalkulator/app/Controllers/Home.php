<?php

namespace App\Controllers;
use App\Models\TiffanyLoveJulio;

class Home extends BaseController
{
    public function login()
    {
        return view('login');
    }
public function register()
    {
        return view('register');
    }
    
    public function dashboard()
    {
        $model = new TiffanyLoveJulio();
        
        echo view('header');
        echo view('menu');
        echo view('dashboard');
       
    }
    
    public function qrcode()
    {
        $model = new TiffanyLoveJulio();
        
        echo view('header');
        echo view('menu');
        echo view('dashboard');
       
    }
    public function dokumen()
    {
        $model = new TiffanyLoveJulio();
        $data['eoffice'] = $model->tampil('eoffice');
        echo view('header');
        echo view('menu');
        echo view('dokumen', $data);
        echo view('footer');
    }

    public function user()
    {
        $model = new TiffanyLoveJulio();
        $data['user'] = $model->tampil('users');
        echo view('header');
        echo view('menu');  
        echo view('user',$data);
        echo view('footer');
    }
      public function tambah_user()
    {
        $model = new TiffanyLoveJulio();
        $data['user'] = $model->tampil('users');
        echo view('header');
        echo view('user', $data);
        echo view('footer');
       
    }
      public function hapus_user($id)
{
    $felixca = new TiffanyLoveJulio();
    $where = array('user_id' => $id);
    $felixca->hapus('penjualankue', $where);

    return redirect()->to('home/user');
}


public function aksi_t_user()
{
    $b = $this->request->getPost('name');
    $c = $this->request->getPost('email');
    $d = $this->request->getPost('password');
    $e = $this->request->getPost('phone'); // Retrieve 'NamaLengkap' from the form
    $f = $this->request->getPost('address');
     // Retrieve 'alamat' from the form

    $data = array(
        'name' => $b,
        'email' => $c,
        'password' => $d,
        'phone' => $e,
        'address' => $f,
        'created_at' => date('Y-m-d H:i:s')
    );

    $felixca = new TiffanyLoveJulio();
    $felixca->tambah('users', $data);

    return redirect()->to('home/user');
}


 public function aksi_e_user()
    {
         $b = $this->request->getPost('name');
    $c = $this->request->getPost('email');
    $d = $this->request->getPost('password');
    $e = $this->request->getPost('phone'); // Retrieve 'NamaLengkap' from the form
    $f = $this->request->getPost('address');
       $data = array(
        'name' => $b,
        'email' => $c,
        'password' => $d,
        'phone' => $e,
        'address' => $f,
        'created_at' => date('Y-m-d H:i:s')
    );


        $felixca = new TiffanyLoveJulio();
        $felixca->edit('users', $data);

        return redirect()->to('home/user');
    } // Penutupan fungsi aksi_t_user ditamb
   
    public function transaksi()
    {
        $tiffany = new TiffanyLoveJulio();
        $data['vira'] = $tiffany->julio('transaksi');
        echo view('header');
        echo view('transaksi', $data);
        echo view('footer');
    }

    public function laporan()
    {
        $tiffany = new TiffanyLoveJulio();
        $data['vira'] = $tiffany->julio('alamak');
        echo view('header');
        echo view('laporan', $data);
        echo view('footer');
    }

    public function reset($id)
    {
        $tiffany = new TiffanyLoveJulio();
        $where = ['id_user' => $id];
        $data = ['password' => password_hash("123", PASSWORD_DEFAULT)];
        $tiffany->edit('user', $data, $where);
        return redirect()->to('home/user');
    }

    public function aksitb_tbku()
    {
        $a = $this->request->getPost('ID User');
        $b = $this->request->getPost('Nama_Buku');
        $c = $this->request->getPost('Tanggal_peminjaman');
        $d = $this->request->getPost('Nomor hp Peminjaman');

        $data = array(
            'ID User' => $a,
            'Nama_Buku' => $b,
            'Tanggal_peminjaman' => $c,
            'Nomor_hp_Peminjaman' => $d
        );

        $felixca = new TiffanyLoveJulio();
        $felixca->tambah('buku', $data);

        return redirect()->to('home/user');
    }

    public function karyawan()
    {
        echo view('header');
        echo view('karyawan');
        echo view('footer');
    }

    public function peminjam()
    {
        $model = new TiffanyLoveJulio();
        $data['peminjam'] = $model->tampil('peminjam');
        echo view('header');
        echo view('peminjam', $data);
        echo view('footer');
    }


    public function peminjaman()
    {
        $model = new TiffanyLoveJulio();
        $data['peminjaman'] = $model->tampil('peminjaman');
        echo view('header');
        echo view('menu');
        echo view('peminjaman', $data);
        echo view('footer');
    }

    public function pengembalian()
    {
        $model = new TiffanyLoveJulio();
        $data['pengembalian'] = $model->tampil('pengembalian');
        echo view('header');
        echo view('pengembalian', $data);
        echo view('footer');
    }

   public function aksi_t_peminjaman()
{
    // Mengambil data dari form menggunakan metode POST
    $TanggalPeminjaman = $this->request->getPost('TanggalPeminjaman');
    $TanggalPengembalian = $this->request->getPost('TanggalPengembalian');
    $StatusPeminjaman = $this->request->getPost('StatusPeminjaman');
    
    // Data yang akan disimpan ke database
    $data = [
        'TanggalPeminjaman' => $TanggalPeminjaman,
        'TanggalPengembalian' => $TanggalPengembalian,
        'StatusPeminjaman' => $StatusPeminjaman,
    ];

    // Inisialisasi model dan simpan data
    $peminjamanModel = new TiffanyLoveJulio();
    $peminjamanModel->tambah('peminjaman', $data);

    // Redirect ke halaman Peminjaman
    return redirect()->to('home/Peminjaman');
}


    public function hapus_peminjaman($id)
    {
        $felixca = new TiffanyLoveJulio();
        $where = array('peminjamanID' => $id);
        $felixca->hapus('peminjaman', $where);

        return redirect()->to('home/peminjaman');
    }
    public function aksi_e_peminjaman($id)
{
    $tiffany = new tiffanylovejulio();
    $where = array('id_peminjaman' => $id);
    $data['felix'] = $tiffany->ambalabu('perpus', $where);

    echo view('header');
    echo view('aksi_e_peminjaman', $data);
    echo view('footer');
}


    public function tambah()
    {
        echo view('header');
        echo view('tambah');
        echo view('footer');
    }
  public function edit()
    {
        echo view('header');
        echo view('edit');
        echo view('footer');
    }
    public function e_buku($id)
    {
        $felixca = new TiffanyLoveJulio();
        $where = array('id_buku' => $id);
        $data['ilhan'] = $felixca->getwhere('buku', $where);

        echo view('header');
        echo view('edit', $data);
        echo view('footer');
    }

    public function aksi_e_buku()
    {
        $a = $this->request->getPost('nama_buku');
        $b = $this->request->getPost('penerbit');
        $c = $this->request->getPost('pengarang');
        $d = $this->request->getPost('tempat_terbit');
        $id = $this->request->getPost('id');

        $data = array(
            'nama_buku' => $a,
            'penerbit' => $b,
            'pengarang' => $c,
            'tempat_terbit' => $d
        );

        $where = array('id_buku' => $id);

        $tiffany = new TiffanyLoveJulio();
        $tiffany->edit('buku', $data, $where);
        return redirect()->to('home/buku');
    }

}
