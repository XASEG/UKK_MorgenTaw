<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class DiskonController extends Controller
{
    public function index()
    {
        return view('diskon_view');
    }

    public function hitung()
    {
        $harga = $this->request->getPost('harga');
        $diskon = $this->request->getPost('diskon');

        if (is_numeric($harga) && is_numeric($diskon)) {
            $potongan = ($harga * $diskon) / 100;
            $hargaSetelahDiskon = $harga - $potongan;
            $hasil = "$diskon% -> " . number_format($potongan, 0, ',', '.') . "rb<br>"
                   . number_format($harga, 0, ',', '.') . "rb - " 
                   . number_format($potongan, 0, ',', '.') . "rb = "
                   . number_format($hargaSetelahDiskon, 0, ',', '.') . "rb";
        } else {
            $hasil = "Input tidak valid!";
        }

        return $this->response->setJSON(['hasil' => $hasil]);
    }
}
