<?php
namespace App\Models;
use CodeIgniter\Model;

class Tiffanylovejulio extends Model
{
    public function tampil($table)
    {
        return $this->db
            ->table($table)
            ->get()
            ->getResult(); // Corrected to getResult() with proper case
    }

    public function edit($table, $data, $where)
    {
        return $this->db
            ->table($table)
            ->update($data, $where);
    }

    public function getwhere($table, $where)
    {
        return $this->db
            ->table($table)
            ->getWhere($where)
            ->getRow();
    }

    public function tambah($table, $data)
    {
        return $this->db
            ->table($table)
            ->insert($data);
    }

    public function hapus($table, $where)
    {
        return $this->db
            ->table($table)
            ->delete($where);
    }
}
