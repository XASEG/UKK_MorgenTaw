<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "absensi";
$connection = mysqli_connect("$id","$name","$qrcode");
$select_db = mysqli_select_db($connection, $absensi);
if(!$select_db)
{
	echo("connection terminated");
}
?>