<form action="<?= base_url('home/aksi_edit_user') ?>" method="post">
    <input type="hidden" name="id_user" value="<?= esc($user->id_user) ?>">
    <label>Username:</label>
    <input type="text" name="username" class="form-control" value="<?= esc($user->username) ?>" required>
    <label>Password:</label>
    <input type="password" name="password" class="form-control">
    <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>
</form>
