<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penghitung Diskon</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { text-align: center; font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; }
        .container { margin: 50px auto; width: 90%; max-width: 400px; background: white; padding: 20px; 
                     border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        h2 { margin-bottom: 20px; color: #333; }
        .input-box { width: 100%; padding: 10px; font-size: 18px; margin-bottom: 15px; border: 1px solid #ccc; 
                     border-radius: 5px; text-align: center; }
        .button-container { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px; }
        .button { padding: 15px; font-size: 18px; border: none; background: #3498db; color: white; cursor: pointer; 
                  border-radius: 5px; transition: 0.3s; }
        .button:hover { background: #2980b9; }
        .equal-button { grid-column: span 3; background: #2ecc71; }
        .equal-button:hover { background: #27ae60; }
        .modal { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); 
                 background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.3); 
                 text-align: center; width: 80%; max-width: 300px; }
        .modal p { font-size: 18px; margin-bottom: 10px; }
        .modal button { background: #e74c3c; color: white; border: none; padding: 10px 15px; border-radius: 5px; 
                        font-size: 16px; cursor: pointer; }
        .modal button:hover { background: #c0392b; }
    </style>
</head>
<body>

    <div class="container">
        <h2>Penghitung Diskon</h2>
      <input type="text" id="harga" class="input-box" placeholder="Masukkan Harga (Rp)">


      <input type="number" id="diskon" class="input-box" placeholder="Masukkan Diskon (%)" min="1" max="100">

        
        <div class="button-container">
            <?php for ($i = 1; $i <= 9; $i++): ?>
                <button class="button" onclick="tambahAngka(<?= $i ?>)"><?= $i ?></button>
            <?php endfor; ?>
            <button class="button" onclick="tambahAngka(0)">0</button>
            <button class="button equal-button" onclick="hitungDiskon()">= Hitung</button>
        </div>
    </div>

    <div id="modal" class="modal">
        <p id="hasil"></p>
        <button onclick="tutupModal()">OK</button>
    </div>

    <script>

     document.getElementById('harga').addEventListener('input', function () {
    let nilai = this.value.replace(/\D/g, ""); // Hanya angka
    nilai = parseInt(nilai, 10);
    if (isNaN(nilai) || nilai < 1) nilai = 1; // Pastikan harga minimal 1

    this.value = nilai.toLocaleString("id-ID"); // Format angka dengan titik
});



        function tambahAngka(angka) {
            let hargaInput = document.getElementById('harga');
            hargaInput.value = hargaInput.value + angka;
        }

   function hitungDiskon() {
    let harga = document.getElementById('harga').value.replace(/\./g, ""); // Hilangkan titik sebelum dikirim
    let diskon = document.getElementById('diskon').value;

    if (harga === "" || diskon === "") {
        alert("Harap isi harga dan diskon!");
        return;
    }

    harga = parseInt(harga, 10);
    if (harga <= 0) {
        alert("Harga harus lebih dari 0!");
        return;
    }

    diskon = parseInt(diskon, 10);
    if (diskon < 1 || diskon > 100) {
        alert("Diskon harus antara 1% - 100%");
        return;
    }

    $.post("<?= site_url('hitung') ?>", { harga: harga, diskon: diskon }, function(data) {
        document.getElementById('hasil').innerHTML = data.hasil;
        document.getElementById('modal').style.display = 'block';
    }, 'json');
}

        function tutupModal() {
            document.getElementById('modal').style.display = 'none';
        }
    </script>

</body>
</html>
