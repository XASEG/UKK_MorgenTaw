<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>nama_peminjam</th>
            <th>Buku dipinjam</th>
            <th>tanggal peminjam</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($peminjam as $ilham) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= esc($ilham->nama_peminjam) ?></td>
            <td><?= esc($ilham->buku_dpinjam) ?></td>
            <td><?= esc($ilham->tanggal_peminjam) ?></td>
            <td>
                <a href="<?= base_url('home/tambah/'.$ilham->id_user) ?>">
                    <button type="button" class="btn btn-outline-primary">Tambah</button>
                </a>
                <a href="<?= base_url('home/edit/'.$ilham->id_user) ?>">
                    <button type="button" class="btn btn-outline-primary">Edit</button>
                </a>
                <a href="<?= base_url('home/hapus_peminjaman/'.$ilham->id_peminjaman) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                    <button type="button" class="btn btn-outline-primary">Hapus</button>
                </a>
            </td>
        </tr>
        <?php  
        }
        ?>
    </tbody>
</table>
