<form action="<?= base_url('home/aksi_e_peminjaman') ?>" method="post">
    <div class="form-group">
        <label for="id_tugas">Nama:</label>
        <input type="text" class="form-control" name="nama" id="nama" required>
        <placeholder= Enter buku name="buku">
    </div>

  <div class="form-group">
    <label for="prioritas">prioritas:</label>
    <input list="prioritas" type="text" class="form-control" name="prioritas" id="prioritas" required>
    <datalist id="prioritas">
        <option value="tinggi">
        <option value="sedang">
        <option value="rendah">
    </datalist>
</div>

    <div class="form-group">
        <label for="tanggal">tanggal:</label>
        <input type="date" class="form-control" name="tanggal" id="tanggal" required>
    </div>

    <button type="submit" class="btn btn-primary">Tambah Data</button>
</form>
