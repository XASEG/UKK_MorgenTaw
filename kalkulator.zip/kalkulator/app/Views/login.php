<?php
include "koneksi.php";
session_start(); // Pastikan session dimulai jika menggunakan session
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Login Perpustakaan</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/feather/feather.css">
  <link rel="stylesheet" href="../../vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="../../vendors/typicons/typicons.css">
  <link rel="stylesheet" href="../../vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../css/vertical-layout-light/style.css">
  <link rel="shortcut icon" href="../../images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo">
                <img src="../../images/logo.svg" alt="logo">
              </div>

              <?php
              if (isset($_POST['Login'])) {
                  $Username = $_POST['Username'];
                  $password = $_POST['password'];

                  // Periksa data di database
                  $Data = mysqli_query($koneksi, "SELECT * FROM user WHERE Username='$Username' AND password='$password'");
                  $cek = mysqli_num_rows($Data);

                  if($cek > 0){
                      $_SESSION['user'] = mysqli_fetch_array($Data);
                      echo '<script>alert("Selamat Datang, Login Berhasil"); location.href="peminjaman";</script>';
                  } else {
                      echo '<script>alert("Maaf, Username/password salah")</script>';
                  }
              }
              ?>

              <h4>Selamat Datang</h4>
              <h6 class="fw-light">Masukkan Data Terlebih Dahulu.</h6>
              <form method="post" class="pt-3">
                <div class="form-group">
                  <input type="text" name="Username" class="form-control form-control-lg" placeholder="Username">
                </div>
                <div class="form-group">
                  <input type="password" name="password" class="form-control form-control-lg" placeholder="Password">
                </div>
                <div class="mt-3">
                  <button type="submit" name="Login" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">Login</button>
                </div>
                <div class="text-center mt-4 fw-light">
                  tidak punya akun? <a href="register" class="text-primary">register</a>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
</body>

</html>
