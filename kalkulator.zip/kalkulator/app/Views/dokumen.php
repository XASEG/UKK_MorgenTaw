<a href="<?= base_url('home/dokumen/')?>">
<button class="btn btn-success">tambah</button>
</a>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>id_dokumen</th>
            <th>nama_dokumen</th>
            <th>link_dokumen</th>
            <th>tipe_dokumen</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($eoffice as $ilham) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= esc($ilham->dokumen_id) ?></td>
            <td><?= esc($ilham->nama_dokumen) ?></td>
            <td><?= esc($ilham->link_dokumen) ?></td>
             <td><?= esc($ilham->tipe_dokumen) ?></td>
            <td>
                <a href="<?= base_url('home/tambah_user') ?>">
                    <button type="button" class="btn btn-outline-primary">Tambah</button>
                </a>
                <a href="<?= base_url('home/edit/username') ?>">
                    <button type="button" class="btn btn-outline-primary">Edit</button>
                </a>
  <a href="<?= base_url('home/hapus_user/'.$ilham->id_user) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                    <button type="button" class="btn btn-outline-primary">Hapus</button>
            </td>
        </tr>
        <?php  
        }
        ?>
    </tbody>
</table>
