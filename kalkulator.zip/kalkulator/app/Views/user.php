<a href="<?= base_url('home/felixputuskarnaceca/')?>">
</a>
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>user_id</th>
            <th>name</th>
            <th>password</th>
            <th>phone</th>
            <th>address</th>
            <th>created_at</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($user as $ilham) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= esc($ilham->user_id) ?></td>
            <td><?= esc($ilham->name) ?></td>
            <td><?= esc($ilham->password) ?></td>
            <td><?= esc($ilham->phone) ?></td>
            <td><?= esc($ilham->address) ?></td>
             <td><?= esc($ilham->created_at) ?></td>
            <td>
                <a href="<?= base_url('home/tambah/user_id') ?>">
                    <button type="button" class="btn btn-outline-primary">Tambah</button>
                </a>
                <a href="<?= base_url('home/edit/user_id') ?>">
                    <button type="button" class="btn btn-outline-primary">Edit</button>
                </a>
  <a href="<?= base_url('home/hapus_user/'.$ilham->user_id) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                    <button type="button" class="btn btn-outline-primary">Hapus</button>
            </td>
        </tr>
        <?php  
        }
        ?>
    </tbody>
</table>
