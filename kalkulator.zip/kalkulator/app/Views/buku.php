<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>nama_buku</th>
        <th>Penerbit</th>
        <th>Pengarang</th>
          <th>tahun terbit</th>
            <th>tempat terbit</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($buku as $ilham) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= esc($ilham->nama_buku) ?></td>
            <td><?= esc($ilham->penerbit) ?></td>
            <td><?= esc($ilham->pengarang) ?></td>
              <td><?= esc($ilham->tempat_terbit) ?></td>
            <td>
                <a href="<?= base_url('home/tambah/'.$ilham->id_user) ?>">
                    <button type="button" class="btn btn-outline-primary">Tambah</button>
                </a>
                <a href="<?= base_url('home/edit/'.$ilham->id_user) ?>">
                    <button type="button" class="btn btn-outline-primary">Edit</button>
                </a>
                <a href="<?= base_url('home/hapus/'.$ilham->id_user) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                    <button type="button" class="btn btn-outline-primary">Hapus</button>
                </a>
            </td>
        </tr>
        <?php  
        }
        ?>
    </tbody>
</table>
