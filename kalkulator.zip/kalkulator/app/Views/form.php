<h3>tambah data</h3>
<form action="" method="post">
<table>
	<tr>
		<td width="130">kode barang</td>
		<td><input type="text" name="peminjaman"></td>
	</tr>
</table>
