<form action="<?= base_url('home/aksi_t_user') ?>" method="post">
    <div class="form-group">
       
<label for="user_id">No:</label>
        <input type="text" class="form-control" name="No" id="No" required>
        <placeholder= Enter buku name="buku">
    </div>

    <div class="form-group">
        <label for="name">name:</label>
        <input type="text" class="form-control" name="name" id="name" required>
    </div>

    <div class="form-group">
        <label for="email">email:</label>
        <input type="text" class="form-control" name="email" id="email" required>
    </div>
    <div class="form-group">
        <label for="Password">Password:</label>
        <input type="text" class="form-control" name="password" id="Password" required>
    </div>
      <div class="form-group">
        <label for="phone">phone:</label>
        <input type="text" class="form-control" name="phone" id="phone" required>
    </div>
     <div class="form-group">
        <label for="address">address:</label>
        <input type="text" class="form-control" name="address" id="address" required>
    </div>
   
    <button type="submit" class="btn btn-primary">Tambah Data</button>
</form>
