<table class="table">
    <thead>
      <tr>
        <th>user</th>
        <th>Buku</th>
        <th>peminjaman</th>
        <th>pengembalian</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($vira as $key => $ilham) {
      ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $ilham->buku ?></td>
        <td>
          <?php
          switch ($ilham->level) {
            case 1:
              echo "super_admin";
              break;
            case 2:
              echo "Admin";
              break;
            case 3:
              echo "Manager";
              break;
            case 4:
              echo "Kasir";
              break;
            case 5:
              echo "Karyawan";
              break;
            default:
              echo "Unknown";
              break;
          }
          ?>
        </td>
        <td>
          <a href="<?= base_url('home/reset/'.$ilham->id_user) ?>">
            <button type="button" class="btn btn-outline-primary">Reset Password</button>
          </a>
        </td>
      </tr>
      <?php  
      }
      ?>
    </tbody>
  </table>
