public function e_buku($id)
{
    $tiffany = new tiffanylovejulio();
    $where = array('id_buku' => $id);
    $data['felix'] = $tiffany->ambalabu('buku', $where);

    echo view('header');
    echo view('e_buku', $data);
    echo view('footer');
}


	public function aksi_e_buku()
{
    $a = $this->request->getPost('nama_buku');
    $b = $this->request->getPost('pengarang');
    $id = $this->request->getPost('id');

    $data = array(
        'nama_buku' => $a,
        'pengarang' => $b
    );

    $where = array('id_buku' => $id);

    $lambalabu = new tiffanylovejulio();
    $lambalabu->edit('buku', $data, $where);
    return redirect()->to('home/buku');
} // Hapus spasi tambahan dan pastikan kurung penutup
public function hapus_buku($id)
{
    $tiffany = new tiffanylovejulio();
    $data = array('id_buku' => $id);
    $tiffany->hapus('buku', $data);
    return redirect()->to('home/buku');
}