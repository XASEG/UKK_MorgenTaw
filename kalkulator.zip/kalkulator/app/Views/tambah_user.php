<form action="<?= base_url('home/aksi_t_user') ?>" method="post">
    <div class="form-group">
        <label for="user_id">username:</label>
        <input type="text" class="form-control" name="name" id="name" required>
        <placeholder= Enter buku name="buku">
    </div>
 <div class="form-group">
        <label for="Password">Password:</label>
        <input type="text" class="form-control" name="Password" id="Password" required>
        <placeholder= Enter buku name="buku">
    </div>
    <div class="form-group">
        <label for="email">email:</label>
        <input type="text" class="form-control" name="phone" id="phone" required>
    </div>

    <div class="form-group">
        <label for="phone">phone:</label>
        <input type="text" class="form-control" name="address" id="address" required>
    </div>
     <div class="form-group">
        <label for="created_at">created_at:</label>
        <input type="date" class="form-control" name="created_at" id="created_at" required>
    </div>
    <button type="submit" class="btn btn-primary">Tambah Data</button>
</form>
