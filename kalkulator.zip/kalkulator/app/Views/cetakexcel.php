<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Excel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-center">Laporan Transaksi Peminjaman</h2>

        <!-- Tambahkan tabel data di sini sesuai kebutuhan -->

        <!-- Tombol Export Excel -->
        <div class="text-center mt-3">
            <button onclick="window.open('laporan-excel.php')" class="btn btn-success">Export Excel</button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
