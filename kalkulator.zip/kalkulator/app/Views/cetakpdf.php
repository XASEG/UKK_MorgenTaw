<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak PDF dengan Bootstrap 5</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <div class="text-center mb-4">
        <h1>Laporan Perpustakaan</h1>
        <p>Informasi terkait buku dan peminjaman di perpustakaan</p>
        <button class="btn btn-primary" onclick="cetakPDF()">Cetak sebagai PDF</button>
    </div>

    <!-- Konten yang akan dicetak -->
    <div id="konten-cetak" class="p-4 border rounded">
        <h2 class="text-center">Data Buku</h2>
        <table class="table table-bordered mt-3">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Judul Buku</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Pengantar Teknologi Informasi</td>
                    <td>Andi Saputra</td>
                    <td>Erlangga</td>
                    <td>2021</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Dasar Pemrograman Web</td>
                    <td>Siti Rahmawati</td>
                    <td>Informatika</td>
                    <td>2020</td>
                </tr>
                <!-- Tambahkan data buku lainnya di sini -->
            </tbody>
        </table>
    </div>
</div>

<!-- html2pdf.js Library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>

<script>
    function cetakPDF() {
        // Pilih elemen yang akan dicetak
        const elemenCetak = document.getElementById('konten-cetak');
        
        // Atur opsi untuk PDF
        const opsi = {
            margin:       0.5,
            filename:     'laporan_perpustakaan.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
        };

        // Generate PDF dari konten menggunakan html2pdf
        html2pdf().set(opsi).from(elemenCetak).save();
    }
</script>

</body>
</html>
