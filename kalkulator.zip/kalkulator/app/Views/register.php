<?php
include "koneksi.php";
session_start(); // Pastikan session dimulai jika menggunakan session
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Register akun Perpustakaan</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/feather/feather.css">
  <link rel="stylesheet" href="../../vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="../../vendors/typicons/typicons.css">
  <link rel="stylesheet" href="../../vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../css/vertical-layout-light/style.css">
  <link rel="shortcut icon" href="../../images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo">
                <img src="../../images/logo.svg" alt="logo">
              </div>

              <?php
             if (isset($_POST['register'])) {
    $Nama = $_POST['Nama'];
    $Email = $_POST['Email'];
    $Alamat = $_POST['Alamat'];
    $No_Telepon = $_POST['No_Telepon'];
    $Username = $_POST['Username'];
    $level = $_POST['level'];
    $password = md5($_POST['password']); // Remember this is not secure for production, consider using password_hash()

    // Periksa data di database
    $Data = mysqli_query($koneksi, "INSERT INTO user (Nama, Email, Alamat, No_Telepon, Username, password, level) 
    VALUES ('$Nama', '$Email', '$Alamat', '$No_Telepon', '$Username', '$password', '$level')");

   if ($Data) {
    echo '<script>alert("Selamat Datang, Register Berhasil"); location.href="login";</script>';
} else {
    echo '<script>alert("Register Gagal, Error: '.mysqli_error($koneksi).'");</script>';
}

    }



              ?>

              <h4>Register akun</h4>
              <h6 class="fw-light">Masukkan Data Terlebih Dahulu.</h6>
              <form method="post" class="pt-3">
                 <div class="form-group">
                  <label class="small mb-1">Nama Lengkap</label>
                  <input type="text" name="Nama_Lengkap" class="form-control form-control-lg" placeholder="Masukkan Nama Lengkap"/>
                </div>
                <div class="form-group">
                   <label class="small mb-1">Email</label>
                  <input type="text" name="Email" class="form-control form-control-lg" placeholder="Masukkan Email"/>
                </div>
                <div class="form-group">
                   <label class="small mb-1">No Telepon</label>
                  <input type="text" name="No_Telepon" class="form-control form-control-lg" placeholder="Masukkan No Telepon"/>
                </div>
                <div class="form-group">
                   <label class="small mb-1">alamat</label>
                  <input type="text" name="alamat" class="form-control form-control-lg" placeholder="Masukkan Alamat"/>
                </div>
                  <div class="form-group">
                   <label class="small mb-1">Username</label>
                  <input type="text" name="Username" class="form-control form-control-lg" placeholder="Masukkan Username">
                </div>
                  <div class="form-group">
                   <label class="small mb-1">Password</label>
                  <input type="text" name="Password" class="form-control form-control-lg" placeholder="Masukkan Password">
                </div>
                 <div class="form-group">
                   <label class="small mb-1">level</label>
                   <select name="level" class="form-control form-control-lg">
                     <option value="admin">admin</option>
                        <option value="peminjam">peminjam</option>
                   </select>
                 
                </div>
                <div class="mt-3">
                  <button type="submit" name="Register" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">Register</button>
                </div>
                <div class="text-center mt-4 fw-light">
                  sudah punya akun? <a href="Login" class="text-primary">login</a>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
</body>

</html>
